/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.agenda.servlet;

import br.com.agenda.conexao.ConnectionFactory;
import br.com.agenda.dao.ContatoDao;
import br.com.agenda.modelo.Contato;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 *
 * @author wslou
 */
public class adicionaContato extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {
    
        //request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        // pegando os parâmetros do request
        request.setCharacterEncoding("UTF-8");
        String nome = request.getParameter("nome");
        String endereco = request.getParameter("endereco");
        String email = request.getParameter("email");
        String dataEmTexto = request.getParameter("dataNascimento");
        Calendar dataNascimento = null;
        // fazendo a conversão da data
        try {
            Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
            dataNascimento = Calendar.getInstance();
            dataNascimento.setTime(date);
        } catch (ParseException e) {
            out.println("Erro de conversão da data");
            return; //para a execução do método
        }

        ConnectionFactory CF = new ConnectionFactory();

        Contato contato = new Contato();

        contato.setNome(nome);
        contato.setEndereco(endereco);
        contato.setEmail(email);
        contato.setDataNascimento(dataNascimento);
        // salva o contato

        ContatoDao dao;
        try {
            dao = new ContatoDao(CF.getConnection());
            dao.adiciona(contato);
        } catch (SQLException ex) {
            Logger.getLogger(adicionaContato.class.getName()).log(Level.SEVERE, null, ex);
        }
        // imprime o nome do contato que foi adicionado
        request.setCharacterEncoding("UTF-8");

        out.println("<html>");
        out.println("<body>");
        out.println("contato " + contato.getNome() + " adicionado com sucesso!");
        out.println("</body>");
        out.println("</html>");

    }

}
