package matematica;

abstract class OperacaoMatematica {
    public abstract double calcular(double x, double y);
}
