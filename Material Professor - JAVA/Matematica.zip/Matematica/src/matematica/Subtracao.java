package matematica;

class Subtracao extends OperacaoMatematica{
    public double calcular(double x, double y){
        return x-y;
    }
}
